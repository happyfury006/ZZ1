#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "arbre.h"

arbre feuille(char c){
  return NULL;
}

arbre noeud(char c, arbre g, arbre d){
  return NULL;
}

int est_feuille(arbre a) {
  return 0;
}

void libere_arbre(arbre *a){
}

void infixe_inverse(FILE *f, arbre a) {
}

void imprime_blancs(FILE *f, int niveau, int est_droit) {
}

void imprime_avec_blancs(FILE *f, arbre a, int niveau, int est_droit) {
}

void imprime_arbre(FILE *f, arbre a){
}


