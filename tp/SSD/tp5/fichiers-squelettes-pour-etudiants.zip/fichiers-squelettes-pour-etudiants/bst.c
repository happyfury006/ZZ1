#include <stdio.h>
#include <stdlib.h>
#include "bst.h"

struct bst * bstCreateNode(int key) {
    // TODO : question 1
}

void bstInorderTraversal(struct bst * root) {
	printf("( ");
    // TODO : question 2
	printf(")\n");
}

struct bst * bstInsert(struct bst * root, int key) {
    // TODO : question 3
}

struct bst * bstMinValue(struct bst * root) {
    // TODO : question 4
	return root;
}

struct bst * bstDelete(struct bst * root, int key) {
    // TODO : question 5
}

void bstFree(struct bst * root) {
    // TODO : question 6
}

void bstDisplay(struct bst * root) {
    // TODO : question 7
}

