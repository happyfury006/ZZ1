#ifndef base_h
#define base_h

#include "listes.h"

void setBase(int b);

void printBaseB(list * );

int baseToDec(list*);
int baseToDec2(list*);

list* decToBase(int);

#endif