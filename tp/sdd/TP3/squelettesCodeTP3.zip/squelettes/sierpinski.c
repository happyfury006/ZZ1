#include <stdlib.h>
#include <stdio.h>
#include "sierpinski.h"


list_triangles * addTriangle(list_triangles * l,triangle ABC){
	list_triangles * l2=NULL;
	// A compléter Question 16


	return l2;
}


void sierpinski_n(list_triangles * l,int n){
	// A compléter Question 16
}

void listTrianglesFree(list_triangles * l){
	// A compléter Question 16
}
