#ifndef ROMAINS_H
#define ROMAINS_H


int nombreRomainToDecimal(char* strRomain);

#endif